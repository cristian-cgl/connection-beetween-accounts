const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");
const { STSClient, AssumeRoleCommand } = require("@aws-sdk/client-sts");

async function assumentRole() {
    
    const client = new STSClient({
        region: "us-east-1"
    });

    const response = await client.send(
        new AssumeRoleCommand({
            RoleArn: "arn:aws:iam::471112640625:role/role-account2-lambda-example-dev",
            RoleSessionName: "lambda-example-dev-role"
        })
    );


    return response.Credentials;
}

async function getAppVersion(client) {
    const command = new GetItemCommand({
        TableName: "arn:aws:dynamodb:us-east-1:471112640625:table/config_table",
        Key: {
            "id": { "S": "app-version" }
        }
    });
    const reply = await client.send(command);
    return reply.Item.version.S;
}

// index.js
exports.handler = async (event) => {
    console.log("Evento recibido:", event);

    const role = await assumentRole();
    const client = new DynamoDBClient({
        region: "us-east-1",
        credentials: {
            accessKeyId: role.AccessKeyId,
            secretAccessKey: role.SecretAccessKey,
            sessionToken: role.SessionToken
        }
    });

    const version = await getAppVersion(client);
    console.log("Version:", version);

    return {
        statusCode: 200,
        body: JSON.stringify({ message: "¡Hola desde Lambda! v" + version }),
    };
};