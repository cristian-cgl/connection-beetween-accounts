const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");
const client = new DynamoDBClient({
    region: "us-east-1"
});

async function getAppVersion() {
    const command = new GetItemCommand({
        TableName: "arn:aws:dynamodb:us-east-1:471112640625:table/config_table",
        Key: {
            "id": { "S": "app-version" }
        }
    });
    const reply = await client.send(command);
    return reply.Item.version.S;
}

// index.js
exports.handler = async (event) => {
    console.log("Evento recibido:", event);

    const version = await getAppVersion();
    console.log("Version:", version);

    return {
        statusCode: 200,
        body: JSON.stringify({ message: "¡Hola desde Lambda! v" + version }),
    };
};